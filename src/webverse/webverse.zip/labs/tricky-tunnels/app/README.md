# Tricky Tunnels (Easy)

Goal: Find the information disclosure and recover the flag.

- Base URL: http://localhost:8088
- API docs: http://localhost:8088/docs

Hint: Look for endpoints that should never be exposed in production.